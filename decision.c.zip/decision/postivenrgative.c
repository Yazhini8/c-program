#include<stdio.h>
int main()
{
	int num;
	printf("Enter the number:");
	scanf("%d",&num);
	if(num>0)
	   printf("positive");
	else if(num<0)
	   printf("Negative");
	else
	   printf("Zero");
	return 0;
}
