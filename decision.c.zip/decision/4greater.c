#include <stdio.h>

int main() {
    int a, b, c, d, greatest;
    printf("Enter four numbers: ");
    scanf("%d %d %d %d", &a, &b, &c, &d);
    if (a > b) {
        if (a > c) {
            if (a > d) {
                greatest = a;
            } else {
                greatest = d;
            }
        } else {
            if (c > d) {
                greatest = c;
            } else {
                greatest = d;
            }
        }
    } else {
        if (b > c) {
            if (b > d) {
                greatest = b;
            } else {
                greatest = d;
            }
        } else {
            if (c > d) {
                greatest = c;
            } else {
                greatest = d;
            }
        }
    }
    printf("The greatest number is: %d\n", greatest);

    return 0;
}


