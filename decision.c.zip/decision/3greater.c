
#include<stdio.h>
int main()
{
	int a,b,c;
	printf("Enter any 3 numbers");
	scanf("%d,%d,%d",&a,&b,&c);
	 if(a>b)
	 {
           if(a>c)
	   
		   printf("Enter a is a greatest number");
	   else
	   
		   printf("Enter c is a greatest number");
	  }
	  else
	  {
	      if(b<c)
			 printf("Enter b is greatest");
	      else
			 printf("Enter c is greatest");
	  }
	 
  return 0;
}










   

