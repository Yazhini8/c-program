#include<stdio.h>
int main()
 {
    int marks;
	printf("enter the number");
    scanf("%d",&marks);
 switch(marks)
 {
 case 90:
	 printf("A");
	  break;
case 80:
	 printf("B");
         break;
case 50:
	 printf("c");
default:
	 printf("Default case is match");
}
return 0;
}


