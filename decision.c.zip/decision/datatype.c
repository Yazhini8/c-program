#include<stdio.h>
int main()
{
	int myint = 10;
	float myfloat = 3.14;
	char mychar = 'A';
	{
	printf("integer value: %d\n",myint);
	printf("float value: %f \n",myfloat);
	printf("char value: %c \n",mychar);
	}
	return 0;
}
