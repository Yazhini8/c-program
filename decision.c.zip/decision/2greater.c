
#include<stdio.h>
int main()
{
	int a,b;
	printf("Enter any two number");
	scanf("%d,%d",&a,&b);
	if(a>b)
	{
		printf("Enter a is greatest number");
	}
	else
	{
		printf("Enter b is a greatest number");
	return 0;
	}
}
